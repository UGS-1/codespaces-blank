<?php

/* SELECT s.session_user_id, s.session_ip, s.session_viewonline FROM phpbb_sessions s WHERE s.session_time >= 1213032780 AND s.session_user_id <> 1 */

$expired = (time() > 1213033128) ? true : false;
if ($expired) { return; }

$this->sql_rowset[$query_id] = array (
  0 => 
  array (
    'session_user_id' => '2',
    'session_ip' => '85.154.42.232',
    'session_viewonline' => '1',
  ),
);
?>