<?php
$expired = (time() > 1244569098) ? true : false;
if ($expired) { return; }

$data = array (
  'name' => 'subsilver2',
  'copyright' => '&copy; phpBB Group, 2003',
  'version' => '3.0.0',
  'parse_css_file' => false,
  'filetime' => 1207590191,
);
?>