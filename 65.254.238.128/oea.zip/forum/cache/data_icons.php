<?php
$expired = (time() > 1244570866) ? true : false;
if ($expired) { return; }

$data = array (
  1 => 
  array (
    'img' => 'misc/fire.gif',
    'width' => 16,
    'height' => 16,
    'display' => true,
  ),
  5 => 
  array (
    'img' => 'misc/star.gif',
    'width' => 16,
    'height' => 16,
    'display' => true,
  ),
  6 => 
  array (
    'img' => 'misc/radioactive.gif',
    'width' => 16,
    'height' => 16,
    'display' => true,
  ),
  4 => 
  array (
    'img' => 'misc/heart.gif',
    'width' => 16,
    'height' => 16,
    'display' => true,
  ),
  7 => 
  array (
    'img' => 'misc/thinking.gif',
    'width' => 16,
    'height' => 16,
    'display' => true,
  ),
  9 => 
  array (
    'img' => 'smile/question.gif',
    'width' => 16,
    'height' => 16,
    'display' => true,
  ),
  10 => 
  array (
    'img' => 'smile/alert.gif',
    'width' => 16,
    'height' => 16,
    'display' => true,
  ),
  8 => 
  array (
    'img' => 'smile/info.gif',
    'width' => 16,
    'height' => 16,
    'display' => true,
  ),
  2 => 
  array (
    'img' => 'smile/redface.gif',
    'width' => 16,
    'height' => 16,
    'display' => true,
  ),
  3 => 
  array (
    'img' => 'smile/mrgreen.gif',
    'width' => 16,
    'height' => 16,
    'display' => true,
  ),
);
?>