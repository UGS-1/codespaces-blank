<?php

/* SELECT * FROM phpbb_smilies ORDER BY LENGTH(code) DESC */

$expired = (time() > 1213035564) ? true : false;
if ($expired) { return; }

$this->sql_rowset[$query_id] = array (
  0 => 
  array (
    'smiley_id' => '32',
    'code' => ':twisted:',
    'emotion' => 'Twisted Evil',
    'smiley_url' => 'icon_twisted.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '32',
    'display_on_posting' => '1',
  ),
  1 => 
  array (
    'smiley_id' => '40',
    'code' => ':mrgreen:',
    'emotion' => 'Mr. Green',
    'smiley_url' => 'icon_mrgreen.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '40',
    'display_on_posting' => '1',
  ),
  2 => 
  array (
    'smiley_id' => '16',
    'code' => ':shock:',
    'emotion' => 'Shocked',
    'smiley_url' => 'icon_eek.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '16',
    'display_on_posting' => '1',
  ),
  3 => 
  array (
    'smiley_id' => '6',
    'code' => ':smile:',
    'emotion' => 'Smile',
    'smiley_url' => 'icon_e_smile.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '6',
    'display_on_posting' => '1',
  ),
  4 => 
  array (
    'smiley_id' => '37',
    'code' => ':arrow:',
    'emotion' => 'Arrow',
    'smiley_url' => 'icon_arrow.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '37',
    'display_on_posting' => '1',
  ),
  5 => 
  array (
    'smiley_id' => '42',
    'code' => ':ugeek:',
    'emotion' => 'Uber Geek',
    'smiley_url' => 'icon_e_ugeek.gif',
    'smiley_width' => '17',
    'smiley_height' => '18',
    'smiley_order' => '42',
    'display_on_posting' => '1',
  ),
  6 => 
  array (
    'smiley_id' => '41',
    'code' => ':geek:',
    'emotion' => 'Geek',
    'smiley_url' => 'icon_e_geek.gif',
    'smiley_width' => '17',
    'smiley_height' => '17',
    'smiley_order' => '41',
    'display_on_posting' => '1',
  ),
  7 => 
  array (
    'smiley_id' => '33',
    'code' => ':roll:',
    'emotion' => 'Rolling Eyes',
    'smiley_url' => 'icon_rolleyes.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '33',
    'display_on_posting' => '1',
  ),
  8 => 
  array (
    'smiley_id' => '31',
    'code' => ':evil:',
    'emotion' => 'Evil or Very Mad',
    'smiley_url' => 'icon_evil.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '31',
    'display_on_posting' => '1',
  ),
  9 => 
  array (
    'smiley_id' => '21',
    'code' => ':cool:',
    'emotion' => 'Cool',
    'smiley_url' => 'icon_cool.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '21',
    'display_on_posting' => '1',
  ),
  10 => 
  array (
    'smiley_id' => '36',
    'code' => ':idea:',
    'emotion' => 'Idea',
    'smiley_url' => 'icon_idea.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '36',
    'display_on_posting' => '1',
  ),
  11 => 
  array (
    'smiley_id' => '3',
    'code' => ':grin:',
    'emotion' => 'Very Happy',
    'smiley_url' => 'icon_e_biggrin.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '3',
    'display_on_posting' => '1',
  ),
  12 => 
  array (
    'smiley_id' => '29',
    'code' => ':oops:',
    'emotion' => 'Embarrassed',
    'smiley_url' => 'icon_redface.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '29',
    'display_on_posting' => '1',
  ),
  13 => 
  array (
    'smiley_id' => '28',
    'code' => ':razz:',
    'emotion' => 'Razz',
    'smiley_url' => 'icon_razz.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '28',
    'display_on_posting' => '1',
  ),
  14 => 
  array (
    'smiley_id' => '9',
    'code' => ':wink:',
    'emotion' => 'Wink',
    'smiley_url' => 'icon_e_wink.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '9',
    'display_on_posting' => '1',
  ),
  15 => 
  array (
    'smiley_id' => '30',
    'code' => ':cry:',
    'emotion' => 'Crying or Very Sad',
    'smiley_url' => 'icon_cry.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '30',
    'display_on_posting' => '1',
  ),
  16 => 
  array (
    'smiley_id' => '19',
    'code' => ':???:',
    'emotion' => 'Confused',
    'smiley_url' => 'icon_e_confused.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '19',
    'display_on_posting' => '1',
  ),
  17 => 
  array (
    'smiley_id' => '22',
    'code' => ':lol:',
    'emotion' => 'Laughing',
    'smiley_url' => 'icon_lol.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '22',
    'display_on_posting' => '1',
  ),
  18 => 
  array (
    'smiley_id' => '15',
    'code' => ':eek:',
    'emotion' => 'Surprised',
    'smiley_url' => 'icon_e_surprised.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '15',
    'display_on_posting' => '1',
  ),
  19 => 
  array (
    'smiley_id' => '25',
    'code' => ':mad:',
    'emotion' => 'Mad',
    'smiley_url' => 'icon_mad.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '25',
    'display_on_posting' => '1',
  ),
  20 => 
  array (
    'smiley_id' => '12',
    'code' => ':sad:',
    'emotion' => 'Sad',
    'smiley_url' => 'icon_e_sad.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '12',
    'display_on_posting' => '1',
  ),
  21 => 
  array (
    'smiley_id' => '35',
    'code' => ':?:',
    'emotion' => 'Question',
    'smiley_url' => 'icon_question.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '35',
    'display_on_posting' => '1',
  ),
  22 => 
  array (
    'smiley_id' => '11',
    'code' => ':-(',
    'emotion' => 'Sad',
    'smiley_url' => 'icon_e_sad.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '11',
    'display_on_posting' => '1',
  ),
  23 => 
  array (
    'smiley_id' => '39',
    'code' => ':-|',
    'emotion' => 'Neutral',
    'smiley_url' => 'icon_neutral.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '39',
    'display_on_posting' => '1',
  ),
  24 => 
  array (
    'smiley_id' => '34',
    'code' => ':!:',
    'emotion' => 'Exclamation',
    'smiley_url' => 'icon_exclaim.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '34',
    'display_on_posting' => '1',
  ),
  25 => 
  array (
    'smiley_id' => '2',
    'code' => ':-D',
    'emotion' => 'Very Happy',
    'smiley_url' => 'icon_e_biggrin.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '2',
    'display_on_posting' => '1',
  ),
  26 => 
  array (
    'smiley_id' => '14',
    'code' => ':-o',
    'emotion' => 'Surprised',
    'smiley_url' => 'icon_e_surprised.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '14',
    'display_on_posting' => '1',
  ),
  27 => 
  array (
    'smiley_id' => '18',
    'code' => ':-?',
    'emotion' => 'Confused',
    'smiley_url' => 'icon_e_confused.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '18',
    'display_on_posting' => '1',
  ),
  28 => 
  array (
    'smiley_id' => '20',
    'code' => '8-)',
    'emotion' => 'Cool',
    'smiley_url' => 'icon_cool.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '20',
    'display_on_posting' => '1',
  ),
  29 => 
  array (
    'smiley_id' => '27',
    'code' => ':-P',
    'emotion' => 'Razz',
    'smiley_url' => 'icon_razz.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '27',
    'display_on_posting' => '1',
  ),
  30 => 
  array (
    'smiley_id' => '5',
    'code' => ':-)',
    'emotion' => 'Smile',
    'smiley_url' => 'icon_e_smile.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '5',
    'display_on_posting' => '1',
  ),
  31 => 
  array (
    'smiley_id' => '24',
    'code' => ':-x',
    'emotion' => 'Mad',
    'smiley_url' => 'icon_mad.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '24',
    'display_on_posting' => '1',
  ),
  32 => 
  array (
    'smiley_id' => '8',
    'code' => ';-)',
    'emotion' => 'Wink',
    'smiley_url' => 'icon_e_wink.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '8',
    'display_on_posting' => '1',
  ),
  33 => 
  array (
    'smiley_id' => '4',
    'code' => ':)',
    'emotion' => 'Smile',
    'smiley_url' => 'icon_e_smile.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '4',
    'display_on_posting' => '1',
  ),
  34 => 
  array (
    'smiley_id' => '7',
    'code' => ';)',
    'emotion' => 'Wink',
    'smiley_url' => 'icon_e_wink.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '7',
    'display_on_posting' => '1',
  ),
  35 => 
  array (
    'smiley_id' => '38',
    'code' => ':|',
    'emotion' => 'Neutral',
    'smiley_url' => 'icon_neutral.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '38',
    'display_on_posting' => '1',
  ),
  36 => 
  array (
    'smiley_id' => '10',
    'code' => ':(',
    'emotion' => 'Sad',
    'smiley_url' => 'icon_e_sad.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '10',
    'display_on_posting' => '1',
  ),
  37 => 
  array (
    'smiley_id' => '1',
    'code' => ':D',
    'emotion' => 'Very Happy',
    'smiley_url' => 'icon_e_biggrin.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '1',
    'display_on_posting' => '1',
  ),
  38 => 
  array (
    'smiley_id' => '13',
    'code' => ':o',
    'emotion' => 'Surprised',
    'smiley_url' => 'icon_e_surprised.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '13',
    'display_on_posting' => '1',
  ),
  39 => 
  array (
    'smiley_id' => '23',
    'code' => ':x',
    'emotion' => 'Mad',
    'smiley_url' => 'icon_mad.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '23',
    'display_on_posting' => '1',
  ),
  40 => 
  array (
    'smiley_id' => '17',
    'code' => ':?',
    'emotion' => 'Confused',
    'smiley_url' => 'icon_e_confused.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '17',
    'display_on_posting' => '1',
  ),
  41 => 
  array (
    'smiley_id' => '26',
    'code' => ':P',
    'emotion' => 'Razz',
    'smiley_url' => 'icon_razz.gif',
    'smiley_width' => '15',
    'smiley_height' => '17',
    'smiley_order' => '26',
    'display_on_posting' => '1',
  ),
);
?>