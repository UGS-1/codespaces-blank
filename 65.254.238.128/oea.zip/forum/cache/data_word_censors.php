<?php
$expired = (time() > 1317104884) ? true : false;
if ($expired) { return; }

$data = array (
);
?>