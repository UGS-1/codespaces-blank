<?php
$expired = (time() > 1317104883) ? true : false;
if ($expired) { return; }

$data = array (
);
?>