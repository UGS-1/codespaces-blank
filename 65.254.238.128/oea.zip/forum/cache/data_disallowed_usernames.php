<?php
$expired = (time() > 1244572485) ? true : false;
if ($expired) { return; }

$data = array (
);
?>