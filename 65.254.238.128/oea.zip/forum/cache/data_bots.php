<?php
$expired = (time() > 1317104883) ? true : false;
if ($expired) { return; }

$data = array (
  0 => 
  array (
    'user_id' => '39',
    'bot_agent' => 'http://www.tkl.iis.u-tokyo.ac.jp/~crawler/',
    'bot_ip' => '',
  ),
  1 => 
  array (
    'user_id' => '38',
    'bot_agent' => 'Snappy/1.1 ( http://www.urltrends.com/ )',
    'bot_ip' => '',
  ),
  2 => 
  array (
    'user_id' => '28',
    'bot_agent' => 'http://lucene.apache.org/nutch/',
    'bot_ip' => '',
  ),
  3 => 
  array (
    'user_id' => '41',
    'bot_agent' => 'crawleradmin.t-info@telekom.de',
    'bot_ip' => '',
  ),
  4 => 
  array (
    'user_id' => '47',
    'bot_agent' => 'http://www.WISEnutbot.com',
    'bot_ip' => '',
  ),
  5 => 
  array (
    'user_id' => '9',
    'bot_agent' => 'FAST Enterprise Crawler',
    'bot_ip' => '',
  ),
  6 => 
  array (
    'user_id' => '17',
    'bot_agent' => 'heise-IT-Markt-Crawler',
    'bot_ip' => '',
  ),
  7 => 
  array (
    'user_id' => '31',
    'bot_agent' => 'online link validator',
    'bot_ip' => '',
  ),
  8 => 
  array (
    'user_id' => '44',
    'bot_agent' => 'W3 SiteSearch Crawler',
    'bot_ip' => '',
  ),
  9 => 
  array (
    'user_id' => '11',
    'bot_agent' => 'http://www.neomo.de/',
    'bot_ip' => '',
  ),
  10 => 
  array (
    'user_id' => '13',
    'bot_agent' => 'Mediapartners-Google',
    'bot_ip' => '',
  ),
  11 => 
  array (
    'user_id' => '35',
    'bot_agent' => 'SEO search Crawler/',
    'bot_ip' => '',
  ),
  12 => 
  array (
    'user_id' => '36',
    'bot_agent' => 'Seoma [SEO Crawler]',
    'bot_ip' => '',
  ),
  13 => 
  array (
    'user_id' => '15',
    'bot_agent' => 'Feedfetcher-Google',
    'bot_ip' => '',
  ),
  14 => 
  array (
    'user_id' => '19',
    'bot_agent' => 'ibm.com/cs/crawler',
    'bot_ip' => '',
  ),
  15 => 
  array (
    'user_id' => '20',
    'bot_agent' => 'ICCrawler - ICjobs',
    'bot_ip' => '',
  ),
  16 => 
  array (
    'user_id' => '34',
    'bot_agent' => 'Sensis Web Crawler',
    'bot_ip' => '',
  ),
  17 => 
  array (
    'user_id' => '24',
    'bot_agent' => 'msnbot-NewsBlogs/',
    'bot_ip' => '',
  ),
  18 => 
  array (
    'user_id' => '30',
    'bot_agent' => 'OmniExplorer_Bot/',
    'bot_ip' => '',
  ),
  19 => 
  array (
    'user_id' => '10',
    'bot_agent' => 'FAST-WebCrawler/',
    'bot_ip' => '',
  ),
  20 => 
  array (
    'user_id' => '49',
    'bot_agent' => 'Yahoo-MMCrawler/',
    'bot_ip' => '',
  ),
  21 => 
  array (
    'user_id' => '50',
    'bot_agent' => 'Yahoo! DE Slurp',
    'bot_ip' => '',
  ),
  22 => 
  array (
    'user_id' => '14',
    'bot_agent' => 'Google Desktop',
    'bot_ip' => '',
  ),
  23 => 
  array (
    'user_id' => '45',
    'bot_agent' => 'W3C-checklink/',
    'bot_ip' => '',
  ),
  24 => 
  array (
    'user_id' => '46',
    'bot_agent' => 'W3C_*Validator',
    'bot_ip' => '',
  ),
  25 => 
  array (
    'user_id' => '3',
    'bot_agent' => 'AdsBot-Google',
    'bot_ip' => '',
  ),
  26 => 
  array (
    'user_id' => '7',
    'bot_agent' => 'Baiduspider+(',
    'bot_ip' => '',
  ),
  27 => 
  array (
    'user_id' => '26',
    'bot_agent' => 'msnbot-media/',
    'bot_ip' => '',
  ),
  28 => 
  array (
    'user_id' => '42',
    'bot_agent' => 'TurnitinBot/',
    'bot_ip' => '',
  ),
  29 => 
  array (
    'user_id' => '51',
    'bot_agent' => 'Yahoo! Slurp',
    'bot_ip' => '',
  ),
  30 => 
  array (
    'user_id' => '52',
    'bot_agent' => 'YahooSeeker/',
    'bot_ip' => '',
  ),
  31 => 
  array (
    'user_id' => '4',
    'bot_agent' => 'ia_archiver',
    'bot_ip' => '',
  ),
  32 => 
  array (
    'user_id' => '18',
    'bot_agent' => 'heritrix/1.',
    'bot_ip' => '',
  ),
  33 => 
  array (
    'user_id' => '23',
    'bot_agent' => 'MetagerBot/',
    'bot_ip' => '',
  ),
  34 => 
  array (
    'user_id' => '43',
    'bot_agent' => 'voyager/1.0',
    'bot_ip' => '',
  ),
  35 => 
  array (
    'user_id' => '6',
    'bot_agent' => 'Ask Jeeves',
    'bot_ip' => '',
  ),
  36 => 
  array (
    'user_id' => '27',
    'bot_agent' => 'NG-Search/',
    'bot_ip' => '',
  ),
  37 => 
  array (
    'user_id' => '37',
    'bot_agent' => 'SEOsearch/',
    'bot_ip' => '',
  ),
  38 => 
  array (
    'user_id' => '16',
    'bot_agent' => 'Googlebot',
    'bot_ip' => '',
  ),
  39 => 
  array (
    'user_id' => '29',
    'bot_agent' => 'NutchCVS/',
    'bot_ip' => '',
  ),
  40 => 
  array (
    'user_id' => '40',
    'bot_agent' => 'SynooBot/',
    'bot_ip' => '',
  ),
  41 => 
  array (
    'user_id' => '5',
    'bot_agent' => 'Scooter/',
    'bot_ip' => '',
  ),
  42 => 
  array (
    'user_id' => '12',
    'bot_agent' => 'Gigabot/',
    'bot_ip' => '',
  ),
  43 => 
  array (
    'user_id' => '21',
    'bot_agent' => 'ichiro/2',
    'bot_ip' => '',
  ),
  44 => 
  array (
    'user_id' => '22',
    'bot_agent' => 'MJ12bot/',
    'bot_ip' => '',
  ),
  45 => 
  array (
    'user_id' => '33',
    'bot_agent' => 'Seekbot/',
    'bot_ip' => '',
  ),
  46 => 
  array (
    'user_id' => '8',
    'bot_agent' => 'Exabot/',
    'bot_ip' => '',
  ),
  47 => 
  array (
    'user_id' => '25',
    'bot_agent' => 'msnbot/',
    'bot_ip' => '',
  ),
  48 => 
  array (
    'user_id' => '32',
    'bot_agent' => 'psbot/0',
    'bot_ip' => '',
  ),
  49 => 
  array (
    'user_id' => '48',
    'bot_agent' => 'yacybot',
    'bot_ip' => '',
  ),
);
?>