<?php

/* SELECT s.session_user_id, s.session_ip, s.session_viewonline FROM phpbb_sessions s WHERE s.session_time >= 1285568580 AND s.session_user_id <> 1 */

$expired = (time() > 1285568914) ? true : false;
if ($expired) { return; }

$this->sql_rowset[$query_id] = array (
  0 => 
  array (
    'session_user_id' => '16',
    'session_ip' => '84.240.25.69',
    'session_viewonline' => '1',
  ),
);
?>