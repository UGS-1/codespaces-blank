vti_encoding:SR|utf8-nl
vti_author:SR|?
vti_modifiedby:SR|?
vti_timelastmodified:TR|29 Dec 2001 06:23:24 -0000
vti_timecreated:TR|29 Dec 2001 06:23:24 -0000
vti_lineageid:SR|{611F70CE-B20A-47AA-9E01-3993A0436485}
vti_cacheddtm:TX|29 Dec 2001 06:23:26 -0000
vti_filesize:IR|16040
vti_extenderversion:SR|5.0.2.2623
vti_backlinkinfo:VX|index.htm board_eng.htm board.htm fndmtng1.htm summary.htm exe_board.htm
